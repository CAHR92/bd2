from setuptools import setup

setup(name='S1',
      version='0.1.1',
      description='S1',
      author='Plincos',
      author_email='moises@plincos.com',
      packages=['S1'],
      zip_safe=False)