#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
import requests
import datetime
import time
import json
import urllib
from unidecode import unidecode
from pymessenger.bot import Bot

ACCESS_TOKEN = os.environ['ACCESS_TOKEN_FACEBOOK']
ET = "YXM1Szd6T3dCY0VtMFJobnFNSFJMQWtRTzA4MW9YbXJpMTBQUHJ3WkEwekNDWTFQcmtxSlJTTmJCL0JHalJRTUdQbk1iVUp0TGhoWFdYL3habUhHbmc3dVNJdlQxNDQ4UzRxWlZxYlNHVUtrd2pUTTE3a2NXOGZiOFNXeDBOc0hOR2VGYVBlanFEK3UxSVlEMVVvM1puZEMwRFRhMzBURU5aOVZTTVVkbGVCeFcwcGp0cGZSUXlqZ0JZYUVTRjc4cGRvdUVSMlZUQ1BNTE5IbVVRK3RUdz09"
EXP_DATE_ET='2017-11-28'
#qa
id_campana = "1090933"
#produccion
#id_campana = "14092747"
bot = Bot(ACCESS_TOKEN)

class s1Module():

    def renew_token(self):
        try:
            url = "https://qa.s1gateway.com/token/token_services.php"
            payload = {'token':'YXM1Szd6T3dCY0VtMFJobnFNSFJMQWtRTzA4MW9YbXJpMTBQUHJ3WkEwekNDWTFQcmtxSlJTTmJCL0JHalJRTUdQbk1iVUp0TGhoWFdYL3habUhHbmc3dVNJdlQxNDQ4UzRxWlZxYlNHVUtrd2pUTTE3a2NXOGZiOFNXeDBOc0hOR2VGYVBlanFEK3UxSVlEMVVvM1puZEMwRFRhMzBURU5aOVZTTVVkbGVCeFcwcGp0cGZSUXlqZ0JZYUVTRjc4cGRvdUVSMlZUQ1BNTE5IbVVRK3RUdz09','action':'renew'}
            headers = {'content-type': "application/x-www-form-urlencoded"}
            response = requests.request("POST", url, data = payload, headers = headers)
            payload = response.json()

            if response.status_code == 200 and payload['error_msg']==0:
                token = payload['data']
                time_exp =  payload['expire_dt']
                tupla1 = (token, time_exp);
                return tupla1
            else:
                print(payload['error_msg'])    
                return payload['error_msg']
        except requests.exceptions.RequestException as e:
            print(e)

    def test_date_exp_token(self,date_token):
        now = datetime.datetime.now()
        time_exp_date = datetime.datetime.strptime(date_token[:10], "%Y-%m-%d")
        
        if now < time_exp_date:
            print('still alive')
        else:
            tupla = self.renew_token()
            global ET
            ET = tupla[0]
            print(ET)
            global EXP_DATE_ET
            date_ET = tupla[1]
            EXP_DATE_ET = date_ET[:10]
            print(date_ET)
           
    def incomingmessage(self, agent_name, sender_id, dateMessage, message, endSession):
        print("--------------Parametros recibidos----------------------")
        print(message)
        print(endSession)
        print("------application/x-www-form-urlencoded---------------------------------------")
        bot.send_text_message(sender_id, message)
        return True

    def sendmessageN(self,sender_id, Nombre, ApellidoP, ApellidoM,mensaje,motivo="Mensaje"):
        self.test_date_exp_token(EXP_DATE_ET)
        mensaje = unidecode (mensaje)
        mensaje = mensaje.replace('"',"'")
        mensaje = mensaje.replace('&',"Y")
        mensaje = mensaje.replace("\\","/")
        print("--------------Mensaje1------------------------")
        print (str( mensaje))
        print("---------------------------------------------")
        headers = {'Content-Type':'application/x-www-form-urlencoded'}
        contact = {
            "fields": {"name": Nombre, "first_name": ApellidoP,"last_name": ApellidoM, "external_id": sender_id},
            "accounts": [{
                "name": Nombre,
                "account_ext_id": sender_id,
                "account": "",
                "source": "external"}]
            }   
        contact1 = "contact="+ str(contact)
        prevmessage = '{"content":"'+ str(mensaje)+'"'
        message = ',"subject":"'+motivo+'","ext_date":"'+str(datetime.datetime.now().isoformat())+'","ext_id":"'+str(datetime.datetime.now())+'","source":'+'"external"'+',"cpg_id":"'+id_campana+'"}'
        message1 = "message="+prevmessage
        message2 = str(message).replace("'",'"')
        token = "ET="+ str(ET)
        query_args = contact1+"&"
        query_args1 = query_args.replace("'",'"')
        query_args1 = query_args1+message1+message2+"&"+token
        print("--------------Mensaje enviado a S1 -----------")
        print(query_args1)
        print("---------------------------------------------")
        url = "https://qa.s1gateway.com/api/channel/ext_case.php"
        #Payload de ejemplo
        #payload = 'contact={"fields": {"name": "Juan","first_name": "Juan","external_id": "123451"},"accounts": [{"name": "Juan","account_ext_id": "1211","account": "121331","source": "external"}]}&message={"content": "Hola esta es una prueba","subject": "Quiero comprar","ext_date": "2017-6-26 15:06:40","ext_id": "","source": "external","cpg_id":"1090933"}&ET=YXM1Szd6T3dCY0VtMFJobnFNSFJMQWtRTzA4MW9YbXJpMTBQUHJ3WkEwekNDWTFQcmtxSlJTTmJCL0JHalJRTWxsYktpVFdaczM2YmhHRWZFZDlkRXlGN2tCcmM0WEZhYTh2ZUgxUFpNTmYyTU9ucVdRQmg4N2Jxa2x3azRBQzh1dFN3M0EyOGZpandtMU8vYndnNGRYZEMwRFRhMzBURU5aOVZTTVVkbGVCeFcwcGp0cGZSUXlqZ0JZYUVTRjc4cGRvdUVSMlZUQ1BNTE5IbVVRK3RUdz09'
        try:
            r = requests.post(url, data=query_args1, headers=headers)
            bot.send_action(sender_id,'mark_seen')
        except requests.exceptions.Timeout:
            print ("Hay un error de timeout con S1")
        except requests.exceptions.RequestException as e:
            print(e)
        print("--------------Respuesta----------------------")
        print(r.text)
        print("---------------------------------------------")

    def sendmessage(self,sender_id, Nombre, ApellidoP, ApellidoM,mensaje,motivo="Mensaje"):
        self.test_date_exp_token(EXP_DATE_ET)
        mensaje = str(mensaje).replace('"',"'")
        print("--------------Mensaje2------------------------")
        print(mensaje)
        print("---------------------------------------------")
        headers = {'Content-Type':'application/x-www-form-urlencoded'}
        contact = {
            "fields": {"name": Nombre, "first_name": ApellidoP,"last_name": ApellidoM, "external_id": sender_id},
            "accounts": [{
                "name": Nombre,
                "account_ext_id": sender_id,
                "account": "",
                "source": "external"}]
            }   
        contact1 = "contact="+ str(contact)
        prevmessage = '{"content":"'+ mensaje+'"'
        message = ',"subject":"'+motivo+'","ext_date":"'+str(datetime.datetime.now().isoformat())+'","ext_id":"'+str(datetime.datetime.now())+'","source":'+'"external"'+',"cpg_id":"'+id_campana+'"}'
        message1 = "message="+prevmessage
        message2 = str(message).replace("'",'"')
        token = "ET="+ str(ET)
        query_args = contact1+"&"
        query_args1 = query_args.replace("'",'"')
        query_args1 = query_args1+message1+message2+"&"+token
        print("--------------Mensaje enviado a S1 -----------")
        print(query_args1)
        print("---------------------------------------------")
        url = "https://qa.s1gateway.com/api/channel/ext_case.php"
        #Payload de ejemplo
        #payload = 'contact={"fields": {"name": "Juan","first_name": "Juan","external_id": "123451"},"accounts": [{"name": "Juan","account_ext_id": "1211","account": "121331","source": "external"}]}&message={"content": "Hola esta es una prueba","subject": "Quiero comprar","ext_date": "2017-6-26 15:06:40","ext_id": "","source": "external","cpg_id":"1090933"}&ET=YXM1Szd6T3dCY0VtMFJobnFNSFJMQWtRTzA4MW9YbXJpMTBQUHJ3WkEwekNDWTFQcmtxSlJTTmJCL0JHalJRTWxsYktpVFdaczM2YmhHRWZFZDlkRXlGN2tCcmM0WEZhYTh2ZUgxUFpNTmYyTU9ucVdRQmg4N2Jxa2x3azRBQzh1dFN3M0EyOGZpandtMU8vYndnNGRYZEMwRFRhMzBURU5aOVZTTVVkbGVCeFcwcGp0cGZSUXlqZ0JZYUVTRjc4cGRvdUVSMlZUQ1BNTE5IbVVRK3RUdz09'
        try:
            r = requests.post(url, data=query_args1, headers=headers)
            bot.send_action(sender_id,'mark_seen')
        except requests.exceptions.Timeout:
            print ("Hay un error de timeout con S1")
        except requests.exceptions.RequestException as e:
            print(e)
        print("--------------Respuesta----------------------")
        print(r.text)
        print("---------------------------------------------")

    def sendmessageNURL(self,sender_id, Nombre, ApellidoP, ApellidoM,mensaje,motivo="Mensaje con adjunto"):
        self.test_date_exp_token(EXP_DATE_ET)
        headers = {'Content-Type':'application/x-www-form-urlencoded'}
        contact = {
            "fields": {"name": Nombre, "first_name": ApellidoP,"last_name": ApellidoM, "external_id": sender_id},
            "accounts": [{
                "name": Nombre,
                "account_ext_id": sender_id,
                "account": "",
                "source": "external"}]
            }   
        contact1 = "contact="+ str(contact)
        prevmessage = '{"content":"'+ urllib.parse.quote(mensaje)+'"'
        message = ',"subject":"'+motivo+'","ext_date":"'+str(datetime.datetime.now().isoformat())+'","ext_id":"'+str(datetime.datetime.now())+'","source":'+'"external"'+',"cpg_id":"'+id_campana+'"}'
        message1 = "message="+prevmessage
        message2 = str(message).replace("'",'"')
        token = "ET="+ str(ET)
        query_args = contact1+"&"
        query_args1 = query_args.replace("'",'"')
        query_args1 = query_args1+message1+message2+"&"+token
        print("--------------Mensaje enviado a S1 -----------")
        print(query_args1)
        print("---------------------------------------------")
        url = "https://qa.s1gateway.com/api/channel/ext_case.php"
        #Payload de ejemplo
        #payload = 'contact={"fields": {"name": "Juan","first_name": "Juan","external_id": "123451"},"accounts": [{"name": "Juan","account_ext_id": "1211","account": "121331","source": "external"}]}&message={"content": "Hola esta es una prueba","subject": "Quiero comprar","ext_date": "2017-6-26 15:06:40","ext_id": "","source": "external","cpg_id":"1090933"}&ET=YXM1Szd6T3dCY0VtMFJobnFNSFJMQWtRTzA4MW9YbXJpMTBQUHJ3WkEwekNDWTFQcmtxSlJTTmJCL0JHalJRTWxsYktpVFdaczM2YmhHRWZFZDlkRXlGN2tCcmM0WEZhYTh2ZUgxUFpNTmYyTU9ucVdRQmg4N2Jxa2x3azRBQzh1dFN3M0EyOGZpandtMU8vYndnNGRYZEMwRFRhMzBURU5aOVZTTVVkbGVCeFcwcGp0cGZSUXlqZ0JZYUVTRjc4cGRvdUVSMlZUQ1BNTE5IbVVRK3RUdz09'
        try:
            r = requests.post(url, data=query_args1, headers=headers)
            bot.send_action(sender_id,'mark_seen')
        except requests.exceptions.Timeout:
            print ("Hay un error de timeout con S1")
        except requests.exceptions.RequestException as e:
            print(e)
        print("--------------Respuesta----------------------")
        print(r.text)
        print("---------------------------------------------")


    def sendFirstMessage(self, sender_id, Nombre, ApellidoP, ApellidoM, motivo, json):
        headMotivo = "<h2 style='color: #2e6c80;'>Motivo de contacto:</h2><p>"+motivo+"</p>"
        headMensajesA = "<h2 style='color: #2e6c80;'>Mensajes Anteriores:</h2>"
        tableHead = "<table class='editorDemoTable'><thead><tr><td>Mensaje:</td><td>Fecha y hora</td></tr></thead>"
        tbody = "<tbody>"
        tableContent=""
        mensajeFinal =""
        for index,x in enumerate(json):
            tableContent=tableContent+"<tr><td>""Mensaje:"+str(index)+" "+str(x["message"])+"</td><td>"+str(x["fecha"])+"</td></tr>"
        endTable="</tbody></table>"
        mensajeFinal=headMotivo+headMensajesA+tableHead+tbody+tableContent+endTable
        self.sendmessage(sender_id, Nombre, ApellidoP, ApellidoM, mensajeFinal,motivo)


    def sendBackBot(self, sender_id):
        replie = [{"content_type":"text","title":"Menú Principal","payload":"Menú Principal"}]
        bot.send_quick_replies(sender_id,"Para realizar alguna operación regresa al menú principal",replie)


    