import requests
import os
import time

URL_SMS = os.environ['URL_SMS']
MAIL_SMS = os.environ['MAIL_SMS']
CTE_SMS = os.environ['CTE_SMS']
ENCPWD_SMS = os.environ['ENCPWD_SMS']
NUM_TEL_SMS = os.environ['NUM_TEL_SMS']

def fecha_hora():
    fecha = time.strftime("%d/%m/%Y")
    hora = time.strftime("%H:%M:%S")
    return fecha + " " + hora

class send_sms(object):
    def send(error):
        fecha = fecha_hora()
        text = fecha + " error: " + str(error)
        payload = {
            'cte': CTE_SMS,
            'encpwd': ENCPWD_SMS,
            'email': MAIL_SMS,
            'msg': text,
            'numtel': NUM_TEL_SMS,
            'mtipo': 'SMS',
            'auxiliar':'Error chatbot de Dinero Express'
        }
        try:
            r = requests.post(URL_SMS, data=payload, timeout=40)
            if r.status_code == 200:
                print(r.text)
                return True
            else:
                return False
        except Exception as e:
            print("Exception: " + str(e.args))
