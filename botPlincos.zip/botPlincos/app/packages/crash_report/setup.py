from setuptools import setup

setup(name='crash_report',
      version='0.0.1',
      description='Send mini log',
      author='mariachi.io',
      author_email='raul@mariachi.io',
      packages=['crash_report'],
      zip_safe=False)