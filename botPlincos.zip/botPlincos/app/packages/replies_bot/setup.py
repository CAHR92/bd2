from setuptools import setup

setup(name='replies_bot',
      version='0.1',
      description='Bot responses',
      author='Mariachi IO',
      author_email='jose@mariachi.io',
      packages=['replies_bot'],
      zip_safe=False)