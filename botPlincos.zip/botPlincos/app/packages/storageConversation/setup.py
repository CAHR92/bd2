from setuptools import setup

setup(name='storageConversation',
      version='0.2.1',
      description='storageConversation',
      author='Plincos',
      author_email='moises@plincos.com',
      packages=['storageConversation'],
      zip_safe=False)