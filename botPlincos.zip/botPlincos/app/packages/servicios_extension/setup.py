from setuptools import setup

setup(name='servicios_extension',
      version='0.1',
      description='servicios_extension',
      author='Plincos',
      author_email='aldo@plincos.com',
      packages=['servicios_extension'],
      zip_safe=False)