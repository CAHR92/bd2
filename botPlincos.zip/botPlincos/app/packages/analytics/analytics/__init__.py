#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import requests

APPID = os.environ['APP_ID']
ACCESS_TOKEN = os.environ['ACCESS_TOKEN_FACEBOOK']


class analyticsBot():

    def sendAnalyticsEvent(self, num_state,analytics_id,sender_id):
        if isinstance(num_state,str):
            states = {
                'X': {"eventName":"fondear"},
                'C': {"eventName":"cobrado"},
                'E': {"eventName":"generada"},
                'N': {"eventName":"notificada"}, 
                'CA': {"eventName":"cancelado"}
                }
            print("--------------NOTIFICACION -----------")
            print (num_state)
            print("---------------------------------------------")
        else:
            states = {
                4: {"eventName":"mostrar_cancelar_intentos"},
                5: {"eventName":"mostrar_cancelar_transaccion"},
                6: {"eventName":"mostrar_numero_contacto"},
                7: {"eventName":"mostrar_yes_no"},
                10: {"eventName":"leer_saludo"},
                20: {"eventName":"leer_botones_saludo"},
                30: {"eventName":"mostrar_botones_ayuda"},
                31: {"eventName":"leer_botones_ayuda"},
                32: {"eventName":"mostrar.hablar_con_humano"},
                33: {"eventName":"leer.hablar_con_humano"},
                34: {"eventName":"leer.motivos_callcenter"},
                40: {"eventName":"mostrar_terminos_condiciones"},
                41: {"eventName":"leer_quick_menuprincipal"},
                42: {"eventName":"terminos_condiciones2"},
                50: {"eventName":"mostrar_verificar"},
                60: {"eventName":"mostrar_ingresa_nombre_beneficiario"},
                61: {"eventName":"leer_nombre_completo_beneficiario"},
                62: {"eventName":"leer_confirmar_nombre_beneficiario"},
                63: {"eventName":"mostrar_corrige_nombre"},
                64: {"eventName":"leer_nombre_beneficiario"},
                65: {"eventName":"leer_apellido_beneficiario"},
                66: {"eventName":"leer_materno_beneficiario"},
                68: {"eventName":"aceptar_terminos_condiciones"},
                69: {"eventName":"leer_aceptar_terminos_condiciones"},
                70: {"eventName":"mostrar_botones_seleccion_beneficiario"},
                71: {"eventName":"leer_botones_seleccionar_beneficiario"},
                80: {"eventName":"mostrar_contactos"},
                81: {"eventName":"leer_carrusel_contactos"},
                82: {"eventName":"mostrar_pregunta_estado_editar"},
                85: {"eventName":"mostrar_despliega_estados"},
                86: {"eventName":"leer_selecciona_region"},
                87: {"eventName":"leer_selecciona_estado"},
                88: {"eventName":"leer_confirmar_estado"},
                89: {"eventName":"leer_region_federativa"},
                90: {"eventName":"mostrar_pregunta_monto"},
                91: {"eventName":"mostrar_pregunta_estado"},
                100: {"eventName":"leer_monto"},
                110: {"eventName":"mostrar_ingresa_nombre_remitente"},
                111: {"eventName":"leer_nombre_completo_remitente"},
                112: {"eventName":"leer_confirmar_nombre_remitente"},
                113: {"eventName":"mostrar_corrige_nombre_remitente"},
                114: {"eventName":"leer_nombre_remitente"},
                115: {"eventName":"leer_apellido_remitente"},
                116: {"eventName":"leer_materno_remitente"},
                120: {"eventName":"mostrar_fecha_nacimiento"},
                121: {"eventName":"leer_fecha_nacimiento"},
                122: {"eventName":"leer_confirmar_fecha"},
                123: {"eventName":"servicios_verifica_usuario_cliente"},
                130: {"eventName":"mostrar_ingresa_domicilio"},
                132: {"eventName":"leer_confirmar_domicilio"},
                133: {"eventName":"mostrar_calle_numero"},
                134: {"eventName":"leer_calle_numero"},
                135: {"eventName":"leer_colonia"},
                136: {"eventName":"leer_codigo_postal"},
                137: {"eventName":"leer_codigo_postal_again"},
                140: {"eventName":"servicios_valida_usuario_beneficiario_listanegra"},
                150: {"eventName":"servicios_cotiza"},
                151: {"eventName":"leer_confirmar_cotizacion"},
                152: {"eventName":"servicios_genera_folio"},
                153: {"eventName":"mostrar_motivo_de_cancelacion"},
                154: {"eventName":"leer_mostrar_motivos_cancelacion"},
                155: {"eventName":"leer_leer_motivo"},
                160: {"eventName":"mostrar_regresa_inicio"},
                170: {"eventName":"servicios_notificacion_activacion_codigo"},
                180: {"eventName":"leer_ubicacion"},
                250: {"eventName":"mostrar_finish"},
                210: {"eventName":"mostrar_busca_elektra"},
                200: {"eventName":"leer_busca_elektra"},
                220: {"eventName":"mostrar_pregunta_monto_cotizacion"},
                225: {"eventName":"leer_cotizacion"},
                226: {"eventName":"leer_confirmar_cotizacion_flujo2"},
                227: {"eventName":"mostrar_error_confirmacion_transaccion"}
            }
        eventName = states[num_state]['eventName']

        sender_id1 = str(sender_id)

        headers= {'Content-Type':'application/x-www-form-urlencoded'}

        query_args = {
            'event': 'CUSTOM_APP_EVENTS',
            'custom_events': '[{"_eventName":"'+eventName+'","_appVersion":"2.2","user_unique_id":"'+sender_id1+'"}]',
            'application_tracking_enabled': 1,
            'advertiser_tracking_enabled': 1,
            'extinfo': '["mb1"]',
            'page_scoped_user_id': sender_id1,
            'page_id': '217304995439503',
            'debug':'all'
        }

        print("--------------Sender analyticsBot -----------")
        print (query_args)
        print("---------------------------------------------")
        url = 'https://graph.facebook.com/v2.9/'+APPID+'/activities'
        #url1 = 'https://desolate-ridge-49335.herokuapp.com/createLog'
        #requests.post(url1, data=query_args)
        #request_data = urllib.parse.urlencode(query_args)
        #QUITAMOS EL ENCODE YA QUE DE LA VERSION 2.5 PARA ARRIBA EL request lo hace automaticamente
        requests.post(url, data=query_args, headers = headers)