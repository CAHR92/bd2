from setuptools import setup

setup(name='analytics',
      version='0.2.1',
      description='analytics',
      author='Plincos',
      author_email='moises@plincos.com',
      packages=['analytics'],
      zip_safe=False)