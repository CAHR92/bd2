from setuptools import setup

setup(name='triple_des',
      version='0.1',
      description='triple_des',
      author='Plincos',
      author_email='aldo@plincos.com',
      packages=['triple_des'],
      zip_safe=False)