from setuptools import setup

setup(name='bdoracle',
      version='0.1',
      description='Oracle functions',
      author='Mariachi IO',
      author_email='pedro@mariachi.io',
      packages=['bdoracle'],
      zip_safe=False)