import json
import requests
import os

def send_image_url_references(recipient_id, image_url):
    request_endpoint = os.environ['API_GRAPH']
    auth_args = "access_token="+os.environ['ACCESS_TOKEN_FACEBOOK']
    payload = {'recipient': json.dumps({'id': recipient_id}),
                'message': json.dumps({'attachment': {'type': 'image','payload': {'url': image_url}}})}

    response = requests.post(
        request_endpoint,
        params=auth_args,
        json=payload
    )
    result = response.json()
    print("---------------------------")
    print(result)
    if 'error' in result:
        return False
    else:
        return True
    