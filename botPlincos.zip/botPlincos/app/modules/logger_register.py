import logging.handlers
from crash_report import send_sms

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

handler = logging.handlers.RotatingFileHandler(filename='../logs/logs.log', mode='a', maxBytes=1024000, backupCount=100)
handler.setLevel(logging.INFO)

formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)

logger.addHandler(handler)


def write_info(tag, message):
    logger.info(tag + " - " + message)
    print("Log INFO '" + tag + " - " + message + "' escrito.")

def write_error(tag, message):
    logger.error(tag + " - " + message)
    send_sms.send(tag + " - " + message)
    print("Log ERROR '" + tag + " - " + message + "' escrito.")