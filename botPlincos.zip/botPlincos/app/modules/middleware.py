from filters import FilterNames, FilterQuantity, FilterDate, FilterGreetings, FilterState

class MiddlePayload():
	"""Middleware para filtrar formato de mensajes de entrada"""
	def __init__(self):
		self.payload = "arg"
	
	def filter(self, payload):
		print("*********MiddlePayload_filter")
		print(payload)
		if payload.get('message'):
			if payload['message'].get('text') and not payload['message'].get('quick_reply'):
				print("Uno")
				return ['message', payload['message']['text']]
			elif payload['message'].get('quick_reply'):
				print("Dos")
				return ['quick_replies', payload['message']['quick_reply']['payload']]
			elif payload['message'].get('attachments'):
				print("Tres")
				if payload['message']['attachments'][0].get('type'):
					if payload['message']['attachments'][0]['type'] == "image":
						return ['image', payload['message']['attachments'][0]['payload']['url']]
					elif payload['message']['attachments'][0]['type'] == "audio":
						return ['audio', payload['message']['attachments'][0]['payload']['url']]
					#Files
					elif payload['message']['attachments'][0]['type'] == "file":
						return ['file', payload['message']['attachments'][0]['payload']['url']]

					elif payload['message']['attachments'][0]['type'] == "video":
						return ['video', payload['message']['attachments'][0]['payload']['url']]
					elif payload['message']['attachments'][0]['type'] == "location":
						return ['location', payload['message']['attachments'][0]['payload']['coordinates']]
					elif payload['message']['attachments'][0]['type'] == "fallback":
						return payload['message']['attachments'][0]['type']
					else: return False
				else: return False 
			else: return False
		elif payload.get('postback') and payload['postback'].get('payload'):
			print("cuatro")
			return ['postback', payload['postback']['payload']]
		else: return False
class MiddleFAQ():
	"""Middleware para identificar FAQ"""
	def __init__(self):
		self.arg = "arg"
	def filter(self, payload):
		print("FAQ")


class MiddleFilters():
	"""Middleware para filtrar respuestas"""
	def __init__(self):
		self.filters = {
            'date':FilterDate.filter,
            'names':FilterNames.filter,
            'greetings':FilterGreetings.filter,
            'state':FilterState.filter,
            'quantity':FilterQuantity.validate
            }
	def filter(self, set_filter, payload):
		return self.filters[set_filter](payload)

		