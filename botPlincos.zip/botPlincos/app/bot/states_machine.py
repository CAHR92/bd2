#!/usr/bin/env python
# -*- coding: utf-8 -*-
from replies_bot import RepliesBot
from pymessenger.bot import Bot
from bot.replies.repliesL import Replies_L
from bot.replies.repliesE import Replies_E
from bot.replies.repliesS import Replies_S
from analytics import analyticsBot
import bot.states as states
from storageConversation import storageConversationModule
import os

analyticsRequest = analyticsBot()

APPID = os.environ['APP_ID']
ACCESS_TOKEN = os.environ['ACCESS_TOKEN_FACEBOOK']

class StatesMachine(object):
    def __init__(self, ora, user,analytics_id, state):
        self.bot = Bot(ACCESS_TOKEN)
        self.replies_bot = RepliesBot(self.bot)
        self.replies_leer = Replies_L(user, ora, self.replies_bot)
        self.replies_mostrar = Replies_E(user, ora, self.replies_bot)
        self.replies_servicios = Replies_S(user, ora, self.replies_bot)
        self.user = user
        self.analytics_id = analytics_id
        self.ora = ora
        self.state = state
        self.states = {
             4: self.replies_mostrar.cancela_instentos,
             5: self.replies_mostrar.cancela_transaccion,
             6: self.replies_mostrar.numero_contacto,
             7: self.replies_mostrar.yes_no,
            10: self.replies_leer.saludo,
            20: self.replies_leer.botones_saludo,
            30: self.replies_mostrar.botones_ayuda,
            31: self.replies_leer.botones_ayuda,
            32: self.replies_leer.hablar_con_humano,#self.replies_mostrar.hablar_con_humano,
            33: self.replies_leer.hablar_con_humano,
            34: self.replies_leer.motivos_callcenter,
            40: self.replies_mostrar.terminos_condiciones,
            41: self.replies_leer.quick_menuprincipal,
            42: self.replies_mostrar.terminos_condiciones2,
            50: self.replies_mostrar.verificar,
            60: self.replies_mostrar.ingresa_nombre_beneficiario,
            61: self.replies_leer.nombre_completo_beneficiario,
            62: self.replies_leer.confirmar_nombre_beneficiario,
            63: self.replies_mostrar.corrige_nombre,
            64: self.replies_leer.nombre_beneficiario,
            65: self.replies_leer.apellido_beneficiario,
            66: self.replies_leer.materno_beneficiario,
            68: self.replies_mostrar.aceptar_terminos_condiciones,
            69: self.replies_leer.leer_aceptar_terminos_condiciones,
            70: self.replies_mostrar.botones_seleccion_beneficiario,
            71: self.replies_leer.botones_seleccionar_beneficiario,
            80: self.replies_mostrar.contactos,
            81: self.replies_leer.carrusel_contactos,
            82: self.replies_mostrar.pregunta_estado_editar,
            85: self.replies_mostrar.despliega_estados,
            86: self.replies_leer.selecciona_region,
            87: self.replies_leer.selecciona_estado,
            88: self.replies_leer.confirmar_estado,
            89: self.replies_leer.region_federativa,
            90: self.replies_mostrar.pregunta_monto,
            91: self.replies_mostrar.pregunta_estado,
            100: self.replies_leer.monto,
            110: self.replies_mostrar.ingresa_nombre_remitente,
            111: self.replies_leer.nombre_completo_remitente,
            112: self.replies_leer.confirmar_nombre_remitente,
            113: self.replies_mostrar.corrige_nombre_remitente,
            114: self.replies_leer.nombre_remitente,
            115: self.replies_leer.apellido_remitente,
            116: self.replies_leer.materno_remitente,
            120: self.replies_mostrar.fecha_nacimiento,
            121: self.replies_leer.fecha_nacimiento,
            122: self.replies_leer.confirmar_fecha,
            123: self.replies_servicios.verifica_usuario_cliente,
            130: self.replies_mostrar.ingresa_domicilio,
            132: self.replies_leer.confirmar_domicilio,
            133: self.replies_mostrar.calle_numero,
            134: self.replies_leer.calle_numero,
            135: self.replies_leer.colonia,
            136: self.replies_leer.codigo_postal,
            137: self.replies_leer.codigo_postal_again,
            140: self.replies_servicios.valida_usuario_beneficiario_listanegra,
            150: self.replies_servicios.cotiza,
            151: self.replies_leer.confirmar_cotizacion,
            152: self.replies_servicios.genera_folio,
            153: self.replies_mostrar.motivo_de_cancelacion,
            154: self.replies_leer.mostrar_motivos_cancelacion,
            155: self.replies_leer.leer_motivo,
            160: self.replies_mostrar.regresa_inicio,
            170: self.replies_servicios.notificacion_activacion_codigo,
            180: self.replies_leer.ubicacion,
            250: self.replies_mostrar.finish,
            210: self.replies_mostrar.busca_elektra,
            200: self.replies_leer.busca_elektra,
            220: self.replies_mostrar.pregunta_monto_cotizacion,
            225: self.replies_leer.cotizacion,
            226: self.replies_leer.confirmar_cotizacion_flujo2,
            227: self.replies_mostrar.error_confirmacion_transaccion,
            230: self.replies_mostrar.tipo_de_fondeo,
            231: self.replies_leer.tipo_de_fondeo,
            232: self.replies_mostrar.error_tipo_de_fondeo,
            #233: self.replies_mostrar.opcion_pago_tarjeta,
            234: self.replies_mostrar.opcion_pago_tarjeta
        }

    def find_state(self, num_state, payload=None):
        #analyticsRequest.sendAnalyticsEvent(num_state,self.analytics_id,self.user.sender_id)
        storageRequest = storageConversationModule(self.user,self.ora)
        storageRequest.setMessageStates(self.user.sender_id,num_state)
        #analyticsRequest.sendAnalyticsNotification(num_state,self.user.sender_id)
        if payload == None:
            self.show(num_state)
        else:
            if payload[0] == 'postback' or payload[0]=="quick_replies":
                if payload[1] == 'CANCELAR_OPERACION':
                    self.find_state(5)
                elif payload[1] == 'CONTACTO':
                    self.find_state(32)
                elif payload[1] == 'TERMINOS_CONDICIONES':
                    self.find_state(40)
                else:
                    self.read(num_state, payload)
            else:
                self.read(num_state, payload)

    def show(self, num_state):
        self.ora.updateEstado(self.user.sender_id, num_state, 'E')
        self.state.update(states.find(num_state))
        response = self.states[num_state]()
        self.change(response)

    def read(self, num_state, payload):
        if payload[0] in self.state.type_input:
            response = self.states[num_state](payload)
            self.change(response)
        else:
            self.error(1)

    def change(self, response):
        print(str(response))
        try:
            if response[0] == 'find':
                self.find_state(response[1])
            elif response[0] == 'save':
                self.ora.updateEstado(self.user.sender_id, response[1], response[2])
            elif response[0] == 'error':
                self.error(response[1])
            elif response[0] == 'True':
                estado = self.ora.consultaEstado(self.user.sender_id)
                self.ora.updateEstado(self.user.sender_id, estado['estAnterior'], 'L')       
        except:
            self.error(1)

    def error(self, num_error):
        try:
            extra = self.ora.consultaExtras(self.user.sender_id)
            if extra.get('num_int'):
                self.ora.updateExtra(self.user.sender_id, 'num_int',str(int(extra['num_int'])+1))
                if extra['num_int'] >= '1':
                    self.find_state(32)
                    return True
            else:
                 self.ora.addExtra(self.user.sender_id, 'num_int','1')


            if type(self.state.errors[num_error]) == list:
                if len(self.state.errors[num_error]) == 1:
                    self.find_state(self.state.errors[num_error][0])
                else:
                    self.replies_bot.send_alert(self.user.sender_id,self.state.errors[num_error][0])
                    self.find_state(self.state.errors[num_error][1])
            else:
                self.replies_bot.send_alert(self.user.sender_id,self.state.errors[num_error])
        except:
            self.error(1)