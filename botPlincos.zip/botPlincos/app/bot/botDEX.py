from modules.middleware import MiddlePayload, MiddleFilters
from bot.states_machine import StatesMachine
import bot.states as states
import os
import logging
import logging.handlers
from S1 import s1Module
from storageConversation import storageConversationModule
from time import time as time
import modules.logger_register as logger

s1Request = s1Module()


ACCESS_TOKEN = os.environ['ACCESS_TOKEN_FACEBOOK']

class State:
	"""Clase para características de los estados"""
	def __init__(self, state):
		self.num_state = state['state']
		self.type = state['type']
		self.type_input = state['type_input']
		self.filters_availables = state['filters_availables']
		self.errors = state['errors']
	def update(self, state):
		self.num_state = state['state']
		self.type = state['type']
		self.type_input = state['type_input']
		self.filters_availables = state['filters_availables']
		self.errors = state['errors']

class User:
    sender_id = ''
    client_id = ''
    name = ''
    last_name = ''
    mothers_last_name = ''
    firs_time = ''
    disponible = ''

class BotDEX():
	"""Bot DEX"""
	def __init__(self, recipient_id,analytics_id, ora):
		self.recipient_id = recipient_id
		self.ora = ora
		self.analytics_id = analytics_id

	def start(self, payload):
		#print("____----------------------------------111111")
		#print(payload)
		#print("____----------------------------------1111")
	#Primer filtro
		tiempo_inicial = time()

		filter_message = MiddlePayload()
		payload_f = filter_message.filter(payload)
		print("____----------------------------------")
		print(payload_f)
		print("____----------------------------------")
		user = User()
		user = load_client(self.ora, user, self.recipient_id)
		print(user.sender_id)
		print(user.name)
		print(user.last_name)
		print(user.firs_time)
		print(user.mothers_last_name)
		print(user.disponible)

		if user.disponible == "1":
			if payload_f[0] == 'message' or payload_f[0] == 'postback'  or payload_f[0] == 'quick_replies':
				print("mensaje con flag en 1")
				message = payload_f[1]
				storageRequest = storageConversationModule(user,self.ora)
				if storageRequest.validarSalirChat(self.recipient_id,message) == True:
					s1Request.sendmessageN(self.recipient_id,user.name,user.last_name,user.mothers_last_name,message)
			elif payload_f[0] == 'image' or payload_f[0] == 'video':
				print("video/foto con flag en 1")
				url = payload_f[1]
				storageRequest = storageConversationModule(user,self.ora)
				s1Request.sendmessageNURL(self.recipient_id,user.name,user.last_name,user.mothers_last_name,url)
			else:
				print("Tipo no disponible en bot")
				storageRequest = storageConversationModule(user,self.ora)
				storageRequest.noAvalible(self.recipient_id)

		else:
			print("TIPO NO DISPONIBLE")
			state = get_state(self.ora, self.recipient_id)
			state = State(state)
			logger.write_info("botDEX" , "USERID: " + str(self.recipient_id) + " , STATE: " + str(state.num_state) + " , PAYLOAD: " + str(payload_f))
			
		#Segundo filtro
		#FAQ
			if payload_f == False:
				print("payload False")
				return "payload False"

		#Tercer filtro
			if payload_f[0] == 'message' or payload_f[0] == 'quick_replies':
				storageRequest = storageConversationModule(user,self.ora)
				storageRequest.setMessage(self.recipient_id,payload_f[1])
				if len(state.filters_availables) > 0:
					filter_especial = MiddleFilters()
					message = filter_especial.filter(state.filters_availables[0],payload_f[1])
					payload_f[1] = message
			
			state_machine = StatesMachine(self.ora, user, self.analytics_id, state)
			state_machine.find_state(state.num_state, payload_f)

		tiempo_final = time()
		tiempo_ejecucion = tiempo_final - tiempo_inicial
		print("TIEMPO DE EJECUCION: " + str(tiempo_ejecucion))

def load_client(ora, user, recipient_id):
	
	data = ora.validaUsuario(recipient_id, ACCESS_TOKEN)
	user.sender_id = recipient_id
	user.name = data['nombre']
	user.last_name = data['apPaterno']
	user.mothers_last_name = data['apMaterno']
	user.disponible = data['disponible']
	data_user = ora.consultaDatosUsuario(recipient_id)
	if data_user['idCliente'] == None:
		user.firs_time = True
	else: 
		user.firs_time = False
	return user

def get_state(ora, id):
	state_user = ora.consultaEstado(id)
	state = states.find(int(state_user['estActual']))
	return state